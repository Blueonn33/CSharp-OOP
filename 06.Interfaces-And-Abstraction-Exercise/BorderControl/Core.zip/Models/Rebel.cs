﻿using BorderControl.Models.Interfaces;

namespace BorderControl.Models
{
    public class Rebel : INameable, IBuyer
    {
        public Rebel(string name, int age, string group)
        {
            Name = name;
            Age = age;
            Group = group;
        }

        public string Name
        {
            get; private set;
        }
        public int Age
        {
            get; private set;
        }
        public string Group
        {
            get; private set;
        }
        public int Food
        {
            get;
            set;
        }

        public void BuyFood()
        {
            Food += 5;
        }
    }
}
