﻿using WildFarm.Abstract;

namespace WildFarm.FoodModels
{
    public class Meat : Food
    {
        public Meat(int quantity)
            : base(quantity)
        {
        }
    }
}