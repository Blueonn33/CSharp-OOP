﻿using WildFarm.Abstract;

namespace WildFarm.FoodModels
{
    public class Seeds : Food
    {
        public Seeds(int quantity)
            : base(quantity)
        {
        }
    }
}
