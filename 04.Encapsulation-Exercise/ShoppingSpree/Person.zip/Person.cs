﻿namespace ShoppingSpree
{
    public class Person
    {
        private string name;
        private decimal money;

        public Person(string name, decimal money)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Name cannot be empty");

            if (money < 0)
                throw new ArgumentException("Money cannot be negative");

            this.name = name;
            this.money = money;
            Products = new List<Product>();
        }

        public string Name => name;

        public decimal Money
        {
            get => money;
            set
            {
                if (value < 0)
                    throw new ArgumentException("Money cannot be negative");

                money = value;
            }
        }

        public List<Product> Products
        {
            get;
        }
    }
}