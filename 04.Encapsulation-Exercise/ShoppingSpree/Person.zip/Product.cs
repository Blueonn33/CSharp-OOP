﻿namespace ShoppingSpree
{
    public class Product
    {
        private string name;
        private decimal cost;

        public Product(string name, decimal cost)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Name cannot be empty");

            if (cost < 0)
                throw new ArgumentException("Money cannot be negative");

            this.name = name;
            this.cost = cost;
        }

        public string Name => name;

        public decimal Cost => cost;

        public override string ToString() => Name;
    }
}