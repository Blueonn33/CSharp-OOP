﻿namespace Animals
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<Animal> animals = new List<Animal>();
            string animalType = Console.ReadLine();
            string[] animalInput = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);

            while (animalType != "Beast")
            {
                string name = animalInput[0];
                int age = int.Parse(animalInput[1]);
                string gender = animalInput[2];

                try
                {
                    Animal animal = null;

                    switch (animalType)
                    {
                        case "Dog":
                            Dog dog = new(name, age, gender);
                            break;
                        case "Cat":
                            Cat cat = new(name, age, gender);
                            break;
                        case "Frog":
                            Frog frog = new(name, age, gender);
                            break;
                        case "Kitten":
                            Kitten kitten = new(name, age, gender);
                            break;
                        case "Tomcat":
                            Tomcat tomcat = new(name, age, gender);
                            break;
                        default:
                            Console.WriteLine("Invalid input!");
                            break;
                    }

                    animals.Add(animal);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }

                animalType = Console.ReadLine();
                animalInput = Console.ReadLine().Split();
            }

            foreach (var animal in animals)
            {
                Console.WriteLine(animal);
                Console.WriteLine(animal.ProduceSound());
            }
        }
    }
}
