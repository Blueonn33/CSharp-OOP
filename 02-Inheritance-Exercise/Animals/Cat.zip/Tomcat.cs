﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Animals
{
    public class Tomcat : Cat
    {
        public Tomcat(string name, int age, string gender = "Male") : base(name, age, "Male")
        {}

        public override string ProduceSound()
        {
            return "MEOW";
        }
    }
}
