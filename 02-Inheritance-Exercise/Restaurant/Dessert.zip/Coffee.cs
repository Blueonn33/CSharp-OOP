﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant
{
    public class Coffee : HotBeverage
    {
        private const double coffeeMilliliters = 50;
        private const decimal coffeePrice = 3.5m;

        public Coffee(string name, decimal price, double milliliters, double caffeine) : base(name, price, milliliters)
        {
            Caffeine = caffeine;
        }

        public double CoffeeMilliliters => coffeeMilliliters;
        public decimal CoffeePrice => coffeePrice;
        public double Caffeine
        {
            get; set;
        }
    }
}
