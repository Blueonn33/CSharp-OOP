using System;

namespace CarManager.Tests
{
    using NUnit.Framework;

    [TestFixture]
    public class CarManagerTests
    {
        private Car car;

        [SetUp]
        public void Setup()
        {
            car = new Car("Suzuki", "Swift", 10, 100);
        }

        [Test]
        public void CarShouldBeCreatedCorrectly()
        {
            string expectedMake = "Suzuki";
            string expectedModel = "Swift";
            double expectedFuelConsumption = 10;
            double expectedFuelCapacity = 100;
            //double expectedFuelAmount = 0;

            Assert.AreEqual(expectedMake, car.Make);
            Assert.AreEqual(expectedModel, car.Model);
            Assert.AreEqual(expectedFuelConsumption, car.FuelConsumption);
            Assert.AreEqual(expectedFuelCapacity, car.FuelCapacity);
            //Assert.AreEqual(expectedFuelAmount, car.FuelAmount);
        }

        [Test]
        public void CarShouldBeCreatedWithEmptyFuelAmount()
        {
            double expectedFuelAmount = 0;
            Assert.AreEqual(expectedFuelAmount, car.FuelAmount);
        }

        [TestCase(null)]
        [TestCase("")]
        public void CarMakeShouldThrowExceptionWhenValueIsNullOrEmpty(string make)
        {
            ArgumentException exception = Assert.Throws<ArgumentException>(() => new Car(make, "Suzuki", 10, 100));
            Assert.AreEqual("Make cannot be null or empty!", exception.Message);
        }

        [TestCase(null)]
        [TestCase("")]
        public void CarModelShouldThrowExceptionWhenValueIsNullOrEmpty(string model)
        {
            ArgumentException exception = Assert.Throws<ArgumentException>(() => new Car("Suzuki", model, 10, 100));
            Assert.AreEqual("Model cannot be null or empty!", exception.Message);
        }

        [TestCase(-17)]
        [TestCase(0)]
        public void CarFuelConsumptionShouldThrowExceptionWhenValueIsNegativeOrZero(double fuelConsumption)
        {
            ArgumentException exception = Assert.Throws<ArgumentException>(() => new Car("Suzuki", "Swift", fuelConsumption, 100));
            Assert.AreEqual("Fuel consumption cannot be zero or negative!", exception.Message);
        }

        [TestCase(-17)]
        [TestCase(0)]
        public void CarFuelCapacityShouldThrowExceptionWhenValueIsNegativeOrZero(double fuelCapacity)
        {
            ArgumentException exception = Assert.Throws<ArgumentException>(() => new Car("Suzuki", "Swift", 10, fuelCapacity));
            Assert.AreEqual("Fuel capacity cannot be zero or negative!", exception.Message);
        }

        [TestCase(-17)]
        [TestCase(0)]
        public void CarRefuelShouldThrowExceptionWhenFuelIsNegativeOrZero(double fuelToRefuel)
        {
            ArgumentException exception = Assert.Throws<ArgumentException>(() => car.Refuel(fuelToRefuel));
            Assert.AreEqual("Fuel amount cannot be zero or negative!", exception.Message);
        }

        [Test]
        public void CarRefuelShouldIncreaseFuelAmount()
        {
            double expectedFuelAmount = 70;

            car.Refuel(50);
            car.Refuel(20);

            Assert.AreEqual(expectedFuelAmount, car.FuelAmount);
        }

        [Test]
        public void CarRefuelShouldNotIncreaseFuelAmountAboveCapacity()
        {
            double expectedFuelAmount = 100;

            car.Refuel(50);
            car.Refuel(70);

            Assert.AreEqual(expectedFuelAmount, car.FuelAmount);
        }

        [Test]
        public void CarDriveShouldDecreaseFuelAmount()
        {
            double expectedFuelAmount = 90;

            car.Refuel(100);
            car.Drive(100);

            Assert.AreEqual(expectedFuelAmount, car.FuelAmount);
        }

        [Test]
        public void CarShouldThrowExceptionWhenFuelIsNotEnough()
        {
            car.Refuel(10);
            InvalidOperationException exception = Assert.Throws<InvalidOperationException>(() => car.Drive(200));
            Assert.AreEqual("You don't have enough fuel to drive!", exception.Message);
        }
    }
}